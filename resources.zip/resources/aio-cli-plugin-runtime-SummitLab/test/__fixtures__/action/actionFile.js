function main (params) {
  return { payload: 'Hello ' + params.name }
}

exports.main = main
